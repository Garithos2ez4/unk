@extends('layouts.app')

@section('title', 'Página de Inicio')

@section('content')
<h1>esta es un blog</h1>
@endsection