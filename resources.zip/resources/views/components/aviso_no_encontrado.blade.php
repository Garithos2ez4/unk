<div class="aviso_no_encontrado">
    <div class="row text-center">
            <div class="col-12 ">
                <h3 class="text-black-50">El articulo {{$nameProduct}} no se encontro</h3>
            </div>
        </div>
</div>

