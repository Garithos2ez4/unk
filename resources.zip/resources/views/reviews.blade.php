@extends('layouts.app')

@section('title', 'Página de Inicio')

@section('content')
<h1>esta es una review</h1>
@endsection