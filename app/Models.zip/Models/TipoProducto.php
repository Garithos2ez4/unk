<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoProducto extends Model
{
 
    protected $table = 'TipoProducto';

    protected $guarded = ['idTipoProducto'];
    
    protected $fillable = ['tipoProducto'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idTipoProducto' => 'int'
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    public function GrupoProducto()
    {
        return $this->hasMany(GrupoProducto::class,'idTipoProducto');
    }
    
}