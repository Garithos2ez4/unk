<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoriaProducto extends Model
{
 
    protected $table = 'CategoriaProducto';

    protected $guarded = ['idCategoria'];
    
    protected $fillable = ['nombreCategoria'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idCategoria' => 'int'
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    public function GrupoProducto()
    {
        return $this->hasMany(GrupoProducto::class,'idCategoria','idCategoria');
    }
    
}