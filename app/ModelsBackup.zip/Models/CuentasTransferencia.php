<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;

class CuentasTransferencia extends Model
{
 
    protected $table = 'CuentasTransferencia';
    
    protected $primaryKey = 'idCuentaBancaria';

    protected $guarded = ['idCuentaBancaria','idBanco','idEmpresa'];
    
    protected $fillable = ['numeroCuenta',
                            'tipoMoneda',
                            'tipoCuenta',
                            'titular'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idCuentaBancaria' => 'int',
        'idBanco' => 'int',
        'idEmpresa' => 'int',
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    public function MarcaProducto()
    {
        return $this->belongsTo(MarcaProducto::class,'idMarca');
    }
    
    public function Banco()
    {
        return $this->belongsTo(GrupoProducto::class, 'idBanco', 'idBanco');
    }
    
}