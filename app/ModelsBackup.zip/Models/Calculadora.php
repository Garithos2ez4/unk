<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;

class Calculadora extends Model
{
    public $timestamps = false;
 
    protected $table = 'Calculadora';
    
    protected $primaryKey = 'idCalculadora';

    protected $guarded = ['idCalculadora'];
    
    protected $fillable = ['igv',
                            'tasaCambio',
                            'facturacion',
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idCalculadora' => 'int',
        'igv' => 'float',
        'tasaCambio' => 'float',
        'facturacion' => 'float',
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    
}