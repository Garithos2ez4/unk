<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Cache;

class Producto extends Model
{
 
    protected $table = 'Producto';
    
    protected $primaryKey = 'idProducto';

    protected $guarded = ['idProducto','idMarca','idGrupo'];
    
    protected $fillable = ['nombreProducto',
                            'codigoProducto',
                            'UPC',
                            'partNumber',
                            'numeroSerie',
                            'modelo',
                            'precioDolar',
                            'garantia',
                            'descripcionProducto',
                            'imagenProducto1',
                            'imagenProducto2',
                            'imagenProducto3',
                            'imagenProducto4',
                            'estadoProductoWeb'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idProducto' => 'int',
        'idMarca' => 'int',
        'idGrupo' => 'int',
        'precioDolar' => 'float',
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    public function MarcaProducto()
    {
        return $this->belongsTo(MarcaProducto::class,'idMarca');
    }
    
    public function GrupoProducto()
    {
        return $this->belongsTo(GrupoProducto::class, 'idGrupo', 'idGrupoProducto');
    }
    
    public function precioTotalDolar($idEmpresa){
        return $this->calcularPrecio($this->precioDolar,$idEmpresa,1.18);
    }
    
    public function precioTotalSol($idEmpresa,$tc){
        $precio = $this->precioDolar * $tc;
        return $this->calcularPrecio($precio,$idEmpresa,1.18);
    }
    
    private function calcularPrecio($valor,$idEmpresa,$igv){
        $estado = $this->estadoProductoWeb;
        $valorDolar = $this->precioDolar;
        
        $costoigv = $valor * $igv;
        $tsfact = 0;
        
        if ($valorDolar > 0 && $valorDolar < 50) {
            $tsfact = $costoigv * 1.2;
        }elseif($valorDolar >= 50 && $valorDolar < 100){
            $tsfact = $costoigv * 1.13;
        }elseif($valorDolar >= 100 && $valorDolar < 300){
            $tsfact = $costoigv * 1.1;
        }elseif($valorDolar >= 300 && $valorDolar < 600){
            $tsfact = $costoigv * 1.08;
        }elseif($valorDolar >= 600 && $valorDolar < 1000){
            $tsfact = $costoigv * 1.073;
        }elseif($valorDolar >= 1000 && $valorDolar < 1500){
            $tsfact = $costoigv * 1.067;  
        }elseif($valorDolar >= 1500 && $valorDolar < 2000){
            $tsfact = $costoigv * 1.063;
        }elseif($valorDolar >= 2000 && $valorDolar < 2500){
            $tsfact = $costoigv * 1.058;
        }elseif($valorDolar >= 2500){
            $tsfact = $costoigv * 1.05;
        }else {
            $tsfact = $costoigv;
        }
        
        $tfact = $tsfact * 1.01;
        
        $precio = ($tfact + $tsfact)/2;
        
        if($estado == 'OFERTA' || $estado == 'UNICO'){
            return number_format($valor);
        }else{
            switch($idEmpresa){
                case 1:
                    return number_format($precio, 2, '.', '');
                    break;
                case 2:
                    return number_format($precio * 1.06, 2, '.', '');
                    break;
                default:
                    return 999;
            }
        }
    }
    
    public function publicImages(){
       // Definir una clave de caché única para cada instancia del producto
        $cacheKey = 'product_images_' . $this->idProducto;
        
        // Intentar obtener las imágenes del caché
        $images = Cache::get($cacheKey);
        
        // Si las imágenes no están en caché, procesarlas y almacenarlas
        if (!$images) {
            $default = asset('storage/noimagen.webp');
    
            $imagen1 = $this->imagenProducto1 ? asset('storage/'.$this->imagenProducto1) : $default;
            $imagen2 = $this->imagenProducto2 ? asset('storage/'.$this->imagenProducto2) : $default;
            $imagen3 = $this->imagenProducto3 ? asset('storage/'.$this->imagenProducto3) : $default;
            $imagen4 = $this->imagenProducto4 ? asset('storage/'.$this->imagenProducto4) : $default;
    
            $images = [$imagen1, $imagen2, $imagen3, $imagen4];
            
            // Almacenar las imágenes en caché por 60 minutos (o el tiempo que desees)
            Cache::put($cacheKey, $images, 60);
        }
    
        return $images;
    }
    
    public function estadoColor(){
        if ($this->estadoProductoWeb == 'DISPONIBLE') {
            return 'text-success';
        } elseif ($this->estadoProductoWeb == 'OFERTA') {
            return 'text-danger';
        } else {
            return 'text-danger text-decoration-line-through';
        }
    }
    
    public function displayImg($img){
        if($img == "asset('storage/images/noimagen.webp')"){
            return "d-none";
        }else{
            return "";
        }
    }
}