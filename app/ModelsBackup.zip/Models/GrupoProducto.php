<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GrupoProducto extends Model
{
 
    protected $table = 'GrupoProducto';
    
    protected $primaryKey = 'idGrupoProducto';

    protected $guarded = ['idGrupoProducto'];
    
    protected $fillable = ['nombreGrupo'
                            ];

    
    protected $hidden = [
        
    ];

    
    protected $casts = [
        'idGrupoProducto' => 'int'
    ];

    /**
     * Obtener las relaciones del modelo.
     */
    public function Producto()
    {
        return $this->hasMany(Producto::class, 'idGrupo', 'idGrupoProducto');
    }
    
    public function CategoriaProducto()
    {
        return $this->belongsTo(CategoriaProducto::class,'idCategoria');
    }
    
    public function TipoProducto()
    {
        return $this->belongsTo(TipoProducto::class,'idTipoProducto');
    }
}