<?php

namespace App\Services;

interface MarcaServiceInterface 
{
    public function getMarcaBySlug($slug);
}