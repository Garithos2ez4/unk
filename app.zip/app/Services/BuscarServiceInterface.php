<?php

namespace App\Services;

interface BuscarServiceInterface
{
    public function searchProducts($query);
}