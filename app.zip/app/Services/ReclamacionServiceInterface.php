<?php

namespace App\Services;

interface ReclamacionServiceInterface
{
    public function generateReclamo(array $data);
}