<?php

namespace App\Repositories;

interface registroUpdateRepositoryInterface {
    public function update();
    public function get();
}